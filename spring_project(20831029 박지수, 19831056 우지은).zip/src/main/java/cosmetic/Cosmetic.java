package cosmetic;

public class Cosmetic {
	int cosmetic_id;
	String cosmetic_name;
	int cosmetic_price;
	String cosmetic_type;
	int cosmetic_delivery;
	String cosmetic_company;
	String cosmetic_img;
	
	public int getCosmetic_id() {
		return cosmetic_id;
	}
	public void setCosmetic_id(int cosmetic_id) {
		this.cosmetic_id = cosmetic_id;
	}
	public String getCosmetic_name() {
		return cosmetic_name;
	}
	public void setCosmetic_name(String cosmetic_name) {
		this.cosmetic_name = cosmetic_name;
	}
	public int getCosmetic_price() {
		return cosmetic_price;
	}
	public void setCosmetic_price(int cosmetic_price) {
		this.cosmetic_price = cosmetic_price;
	}
	public String getCosmetic_type() {
		return cosmetic_type;
	}
	public void setCosmetic_type(String cosmetic_type) {
		this.cosmetic_type = cosmetic_type;
	}
	public int getCosmetic_delivery() {
		return cosmetic_delivery;
	}
	public void setCosmetic_delivery(int cosmetic_delivery) {
		this.cosmetic_delivery = cosmetic_delivery;
	}
	public String getCosmetic_company() {
		return cosmetic_company;
	}
	public void setCosmetic_company(String cosmetic_company) {
		this.cosmetic_company = cosmetic_company;
	}
	public String getCosmetic_img() {
		return cosmetic_img;
	}
	public void setCosmetic_img(String cosmetic_img) {
		this.cosmetic_img = cosmetic_img;
	}
	
}
