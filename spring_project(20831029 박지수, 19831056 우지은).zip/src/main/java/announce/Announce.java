package announce;

public class Announce {
	int announce_id;
	String announce_title;
	String announce_content;
	
	public int getAnnounce_id() {
		return announce_id;
	}
	public void setAnnounce_id(int announce_id) {
		this.announce_id = announce_id;
	}
	public String getAnnounce_title() {
		return announce_title;
	}
	public void setAnnounce_title(String announce_title) {
		this.announce_title = announce_title;
	}
	public String getAnnounce_content() {
		return announce_content;
	}
	public void setAnnounce_content(String announce_content) {
		this.announce_content = announce_content;
	}
}
